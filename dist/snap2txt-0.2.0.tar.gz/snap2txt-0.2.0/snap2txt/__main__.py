# snap2txt/__main__.py
from snap2txt.saver import main

if __name__ == '__main__':
    main()
